package stepDefinitions;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class MultipleEmployees {

	WebDriver driver;
	WebDriverWait wait;

	@Given("^User is on HRM Home Page$")
	
		public void userIsOnGooglePage() throws Throwable {

    //Create a new instance of the Chrome driver
		System.setProperty("webdriver.chrome.driver", "C:\\Selenium_requirement\\drivers\\chromedriver.exe");
		driver = new ChromeDriver ();
		
		driver.get("http://alchemy.hguy.co/orangehrm");
		driver.manage().window().maximize();
	
}
	@When("^valid \"(.*)\" and \"(.*)\" is entered2$")

	public void user_enters_and(String username, String password) throws Throwable
	
	{	
        //Enter username from Feature file
        driver.findElement(By.id("txtUsername")).sendKeys(username);
	
        //Enter password from Feature file
        driver.findElement(By.id("txtPassword")).sendKeys(password);
	
        //Click Login
        driver.findElement(By.id("btnLogin")).click();
        System.out.println("User Logged in successfully");
	}
	
	@Then("^create job vacancy2$")
		public void showsResults() throws Throwable {
		
		//Click PIM
		driver.findElement(By.xpath("//b[contains(text(),'PIM')]")).click();
	    Thread.sleep(3000);
	    
	    //Add Employee
	    driver.findElement(By.xpath("//input[@id='btnAdd']")).click();
	    	    
    
	    //fill up form
	    //driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    driver.findElement(By.id("firstName")).sendKeys("Ankita"); 
	    Thread.sleep(3000);
	    driver.findElement(By.id("lastName")).sendKeys("Dutta");
	    Thread.sleep(3000);
	    driver.findElement(By.id("chkLogin")).click();
	    Thread.sleep(3000);
	    driver.findElement(By.id("user_name")).sendKeys("ankitadutta");

	    driver.findElement(By.xpath("//input[@id='btnSave']")).click();
	    
	    
	    //Search added employee
	    
	    driver.findElement(By.id("menu_pim_viewEmployeeList")).click();
	    Thread.sleep(2000); 
	    
	    driver.findElement(By.id("empsearch_employee_name_empName")).sendKeys("Ankita Dutta");
	    Thread.sleep(2000); 
	    
	    driver.findElement(By.id("searchBtn")).click();
	    Thread.sleep(4000);
	    
	    String foundEmployee = driver.findElement(By.xpath("//a[contains(text(),'Ankita')]")).getText();
	    Assert.assertEquals(foundEmployee, "Ankita");
	    System.out.println("The added employee name is :" + foundEmployee);
	    Thread.sleep(5000);
	    
	}
	
	@And("^Close the browser2$")
		public void closeTheBrowser() throws Throwable {
	
	   driver.close();
	}
}