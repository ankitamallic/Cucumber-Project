package stepDefinitions;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class CandidateRecruitment {

	WebDriver driver;

	WebDriverWait wait;

	@Given("^User is on Google Home Page$")

		public void userIsOnGooglePage() throws Throwable {

    //Create a new instance of the Chrome driver
		System.setProperty("webdriver.chrome.driver", "C:\\Selenium_requirement\\drivers\\chromedriver.exe");
		driver = new ChromeDriver ();
		
		driver.get("http://alchemy.hguy.co/orangehrm");
		driver.manage().window().maximize();
	
	}
	
	@When("^valid \"(.*)\" and \"(.*)\" is entered$")

	public void user_enters_and(String username, String password) throws Throwable
	
	{	
        //Enter username from Feature file
        driver.findElement(By.id("txtUsername")).sendKeys(username);
	
        //Enter password from Feature file
        driver.findElement(By.id("txtPassword")).sendKeys(password);
	
        //Click Login
        driver.findElement(By.id("btnLogin")).click();
        System.out.println("User Logged in successfully");
	}
	
	@Then("^create Candiate Recruitment$")
		public void showsResults() throws Throwable {

		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
	    driver.findElement(By.xpath("//div[@id='branding']//a//img"));
	    
	//navigate to the recruitment page
	    driver.findElement(By.xpath("//b[contains(text(),'Recruitment')]")).click();
	    Thread.sleep(2000);
	    
	    //Add Candidate
	    driver.findElement(By.id("btnAdd")).click();
	    	    
	    String verifyForm = driver.findElement(By.xpath("//h1[@id='addCandidateHeading']")).getText();
	    System.out.println("The vacancy form title is: " + verifyForm);
	    
	    //fill up form
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    driver.findElement(By.id("addCandidate_firstName")).sendKeys("Ankita"); 
	    driver.findElement(By.id("addCandidate_lastName")).sendKeys("Mallick");
	    driver.findElement(By.id("addCandidate_email")).sendKeys("abcddutta@gmail.com");
	    driver.findElement(By.id("addCandidate_keyWords")).sendKeys("Ankita Mallick");
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	       
	    driver.findElement(By.id("btnSave")).click();
	    
	    
	    //Search added candidate
	    driver.findElement(By.id("menu_recruitment_viewCandidates")).click();
	    
	    driver.findElement(By.id("candidateSearch_candidateName")).sendKeys("Ankita Mallick");
	    Thread.sleep(2000); 
	    
	    driver.findElement(By.id("candidateSearch_keywords")).sendKeys("Ankita Mallick");
	    Thread.sleep(2000);
	    
	    driver.findElement(By.id("btnSrch")).click();
	    
	    String foundVacancy = driver.findElement(By.xpath("//a[contains(text(),'Mallick')]")).getText();
	    System.out.println("The added vacancy name is :" + foundVacancy);
	    
	}
	
	@And("^Close the browser$")
		public void closeTheBrowser() throws Throwable {
	
	   driver.close();
}
}