package stepDefinitions;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;


public class JobVacancy {

	WebDriver driver;
	WebDriverWait wait;

	@Given("^User is on HRM$")

		public void userIsOnGooglePage() throws Throwable
	{
		//Create a new instance of the Chrome driver
		System.setProperty("webdriver.chrome.driver", "C:\\Selenium_requirement\\drivers\\chromedriver.exe");
		driver = new ChromeDriver ();
		
		driver.get("http://alchemy.hguy.co/orangehrm");
		driver.manage().window().maximize();
	}
	
	@When("^valid \"(.*)\" and \"(.*)\" is entered$")

	public void user_enters_and(String username, String password) throws Throwable
	
	{	
        //Enter username from Feature file
        driver.findElement(By.id("txtUsername")).sendKeys(username);
	
        //Enter password from Feature file
        driver.findElement(By.id("txtPassword")).sendKeys(password);
	
        //Click Login
        driver.findElement(By.id("btnLogin")).click();
        System.out.println("User Logged in successfully");
	}

	@Then("^create job vacancy$")
		public void showsResults() throws Throwable {

		driver.manage().timeouts().implicitlyWait(60, TimeUnit.SECONDS);
	    driver.findElement(By.xpath("//div[@id='branding']//a//img"));
	
	    driver.findElement(By.xpath("//b[contains(text(),'Recruitment')]")).click();
	    Thread.sleep(2000);
	    
	    //click on vacancies
	    driver.findElement(By.id("menu_recruitment_viewJobVacancy")).click();
	    driver.findElement(By.id("btnAdd")).click();
	    
	    String verifyForm = driver.findElement(By.xpath("//h1[contains(text(),'Add Job Vacancy')]")).getText();
	    System.out.println("The vacancy form title is: " + verifyForm);
	    
	    //fill up form
	    Select drpList = new Select (driver.findElement(By.id("addJobVacancy_jobTitle")));
	    
	    drpList.selectByVisibleText("DevOps Engineer");
	    Thread.sleep(2000);
	    
	    driver.findElement(By.id("addJobVacancy_name")).sendKeys("Ankita Dutta");
	    driver.findElement(By.id("addJobVacancy_hiringManager")).sendKeys("Test Test");
	    driver.findElement(By.id("btnSave")).click();
	    Thread.sleep(3000);
	    
	    //Search added vacancy
	    driver.findElement(By.id("menu_recruitment_viewJobVacancy")).click();
	    
	    Select searchJobTitle = new Select (driver.findElement(By.id("vacancySearch_jobTitle")));
	    
	    searchJobTitle.selectByVisibleText("DevOps Engineer");
	    Thread.sleep(2000);
	    
	    Select searchVacancy = new Select (driver.findElement(By.id("vacancySearch_jobVacancy")));
	    
	    searchVacancy.selectByVisibleText("Ankita Dutta");
	    Thread.sleep(2000);
	    
	    driver.findElement(By.id("btnSrch")).click();
	    
	    String foundVacancy = driver.findElement(By.xpath("//a[contains(text(),'Ankita Dutta')]")).getText();
	    System.out.println("The added vacancy name is :" + foundVacancy);
	    
	}
	
	@And("^Close browser$")
		public void closeTheBrowser() throws Throwable {
	
	   driver.close();
}
}