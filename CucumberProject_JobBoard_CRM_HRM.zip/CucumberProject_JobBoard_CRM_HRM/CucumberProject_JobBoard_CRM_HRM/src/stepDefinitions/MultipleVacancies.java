package stepDefinitions;

import java.util.concurrent.TimeUnit;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class MultipleVacancies {
	
	WebDriver driver;
    WebDriverWait wait;
		
	@Given("^login with valid \"(.*)\" and \"(.*)\"$")
	public void login_into_Orange_HRM(String username, String password) throws Throwable {
		System.setProperty("webdriver.chrome.driver", "C:\\Selenium_requirement\\drivers\\chromedriver.exe");
		driver = new ChromeDriver ();	
		wait = new WebDriverWait(driver, 10);
		driver.get("http://alchemy.hguy.co/orangehrm");	 
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	        //Enter username from Feature file
	        driver.findElement(By.id("txtUsername")).sendKeys(username);
		
	        //Enter password from Feature file
	        driver.findElement(By.id("txtPassword")).sendKeys(password);
		
	        //Click Login
	        driver.findElement(By.id("btnLogin")).click();
	        System.out.println("User Logged in successfully");
		
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
	}

	@Given("^navigate to the recruitment page for adding vacancies$")
	public void adding_vacancies() throws Throwable {
		driver.findElement(By.xpath("//*[@id=\"menu_recruitment_viewRecruitmentModule\"]")).click();	
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@When("^user  clicks on Vacancies menu item to navigate to vacancies page$")
	public void clicks_on_Vacancies_menu() throws Throwable {
		driver.findElement(By.xpath("//*[@id=\"menu_recruitment_viewJobVacancy\"]")).click();	
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@When("^user clicks on the Add button to the Add Job Vacancy form$")
	public void add_Job_Vacancy_form() throws Throwable {
		driver.findElement(By.xpath("//input[@id='btnAdd']")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}


	@When("^fill Details \"([^\"]*)\" and \"([^\"]*)\"$")
	public void fill_Details_and(String VacancyName, String HiringManager) throws Throwable {
		
		WebElement JobTitle = driver.findElement(By.id("addJobVacancy_jobTitle"));
		Select select = new Select(JobTitle);
		select.selectByValue("3");
		
			
		driver.findElement(By.id("addJobVacancy_name")).sendKeys(VacancyName);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		driver.findElement(By.id("addJobVacancy_hiringManager")).sendKeys(HiringManager);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@When("^click the Save button$")
	public void click_the_Save_button() throws Throwable {
		driver.findElement(By.xpath("//input[@id='btnSave']")).click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	}

	@Then("^verify all the vacanies are successfully created$")
	public void vacanies_successfully_created() throws Throwable {
	   
		driver.findElement(By.xpath("//input[@id='btnBack']")).click();
				
		WebElement verifyJobVacancy = driver.findElement(By.xpath("//a[contains(text(),VacancyName)]"));
		verifyJobVacancy.isSelected();
								
		System.out.println("Job Vacancy is completed successfully: " +verifyJobVacancy);
					
	}

	@Then("^Logout from the browser$")
	public void close_browser() throws Throwable {
		driver.close();
	}	
}
